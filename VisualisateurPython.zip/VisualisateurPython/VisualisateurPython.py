import json
import matplotlib.pyplot as plt
import matplotlib.patches as patches

# Charger le fichier JSON
with open("listeColisPlaced.json", "r") as fichier:
    data = json.load(fichier)

# Extraire les dimensions du camion
largeur_camion = data["largeurCamion"]
longueur_camion = data["longueurCamion"]

# Extraire la liste des colis
colis = data["colis"]

# Créer la figure et les axes
fig, ax = plt.subplots(figsize=(50, 15))
ax.set_xlim(0, largeur_camion)
ax.set_ylim(0, longueur_camion)

# Dessiner les colis
for c in colis:
    rect = patches.Rectangle(
        (c["posX"], c["posY"]),  # Position (x, y)
        c["sizeX"],             # Largeur
        c["sizeY"],             # Hauteur
        linewidth=1,
        edgecolor="blue",
        facecolor="lightblue",
        label=f"Commande {c['numCommande']}" if c == colis[0] else ""
    )
    ax.add_patch(rect)
    # Ajouter le numéro de commande au centre de chaque colis
    ax.text(
        c["posX"] + c["sizeX"] / 2,
        c["posY"] + c["sizeY"] / 2,
        str(c["numCommande"]),
        color="black",
        ha="center",
        va="center",
        fontsize=8
    )

# Ajouter des étiquettes
ax.set_title("Visualisation des Colis dans le Camion")
ax.set_xlabel("Largeur (dm)")
ax.set_ylabel("Longueur (dm)")

# Afficher les limites du camion
ax.set_aspect("equal")
plt.grid(visible=True, linestyle="--", linewidth=0.5)
plt.show()